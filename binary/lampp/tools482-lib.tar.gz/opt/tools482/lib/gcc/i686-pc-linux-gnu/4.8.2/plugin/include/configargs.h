/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.8.2/configure --prefix=/tools482 --with-local-prefix=/tools482 --with-native-system-header-dir=/tools482/include --enable-clocale=gnu --enable-shared --enable-threads=posix --enable-__cxa_atexit --enable-languages=c,c++ --disable-libstdcxx-pch --disable-multilib --disable-bootstrap --disable-libgomp --with-mpfr-include=/home/lfs/gcc-build2/../gcc-4.8.2/mpfr/src --with-mpfr-lib=/home/lfs/gcc-build2/mpfr/src/.libs";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "pentiumpro" } };
